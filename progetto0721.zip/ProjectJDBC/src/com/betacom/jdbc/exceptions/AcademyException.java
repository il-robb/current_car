package com.betacom.jdbc.exceptions;

public class AcademyException extends Exception{

	public AcademyException() {
		super();
	}
	
	public AcademyException(String message) {
		super(message);
	}
	

}
